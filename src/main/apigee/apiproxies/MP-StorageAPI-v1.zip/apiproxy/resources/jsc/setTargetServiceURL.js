var service_url = context.getVariable('propertyset.props.function_url');
context.setVariable('servicecallout.SC-GetSignedUrl.target.url', service_url);
